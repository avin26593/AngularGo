import { FooterComponent } from './footer/footer.component';
import { SearchComponent } from './searcharea/search.component';
import { ModalComponent } from './navbar/modal.component';
import { NavbarComponent } from './navbar/navbar.component';
import { HttpModule } from '@angular/http';
import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent }  from './app.component';

@NgModule({
  imports:      [ BrowserModule, HttpModule ],
  declarations: [ AppComponent, NavbarComponent, ModalComponent, SearchComponent, FooterComponent ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
